package com.example.dresscollection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionSingleton {
    private final String url = "jdbc:mysql://localhost:3306/newapplication";
    private final String user = "root";
    private final String password = "abdullah";

    private static Connection connection;
    private static ConnectionSingleton instance = new ConnectionSingleton();

    private ConnectionSingleton() {
        try {
            connection = DriverManager.getConnection(url, user, password);
        } catch (SQLException e) {
            throw new RuntimeException("Failed to create DB connection", e);
        }
    }

    public static synchronized Connection getConnection() {
        try {
            if (connection == null || connection.isClosed()) {
                // Re-establish connection if closed or null
                connection = DriverManager.getConnection(
                        "jdbc:mysql://localhost:3306/newapplication", "root", "abdullah");
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to get DB connection", e);
        }
        return connection;
    }
}
