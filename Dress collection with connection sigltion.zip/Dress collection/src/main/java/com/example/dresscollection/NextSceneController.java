package com.example.dresscollection;

import javafx.beans.property.ObjectProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.io.File;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DecimalFormat;
import java.util.ResourceBundle;

public class NextSceneController implements Initializable {

    @FXML
    private Label Name, Price, Quality, Size, Type, bossting, color, date, details, discount, Customer;
    @FXML
    private TextField serachfiled;
    @FXML
    private TableView<Dress> tableview;
    @FXML
    private TableColumn<Dress, String> colorcolumn;
    @FXML
    private TableColumn<Dress, String> namecolumn;
    @FXML
    private TableColumn<Dress, String> typecolumn;
    @FXML
    private TableColumn<Dress, Double> pricecolumn;
    @FXML
    private TableColumn<Dress, Integer> quantitycolumn;
    @FXML
    private TableColumn<Dress, String> purchasecolumn;
    @FXML
    private TableColumn<Dress, String> boostedcolum;
    @FXML
    private ImageView imageload;

    private String currentDiscountCode;



    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        loadLastRecord();
        loadTableData();
        serachfiled.textProperty().addListener((observable, oldValue, newValue) -> filterTable(newValue));
    }

    @FXML
    void backScene(ActionEvent event) {
        HelloApplication.changeScene("hello-view.fxml");
    }

    @FXML
    void showDiscount() {
        discount.setText(currentDiscountCode);
    }

    @FXML
    void Editaction() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Coming Soon");
        alert.setHeaderText(null);
        alert.setContentText("This feature is coming soon.");
        alert.showAndWait();
    }

    private void loadLastRecord() {
        try (Connection conn = ConnectionSingleton.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM dresses ORDER BY id DESC LIMIT 1")) {

            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Dress lastDress = new Dress(
                        rs.getString("name"),
                        rs.getString("type"),
                        rs.getString("size"),
                        getColorName(rs.getString("color")),
                        rs.getDouble("price"),
                        rs.getString("details"),
                        rs.getString("gender"),
                        rs.getInt("quantity"),
                        rs.getString("purchase_date"),
                        rs.getString("discount_code"),
                        rs.getString("facebook_boost_status"),
                        rs.getString("image_path")
                );
                updateUIWithDressData(lastDress);
            } else {
                Name.setText("No record found.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void updateUIWithDressData(Dress dress) {
        try {
            Name.setText(dress.getName());
            Type.setText(dress.getType());
            Size.setText(dress.getSize());
            color.setText(dress.getColor());

            DecimalFormat df = new DecimalFormat("0.00");
            Price.setText(df.format(dress.getPrice()));

            details.setText(dress.getDetails());
            Customer.setText(dress.getGender());
            currentDiscountCode = dress.getDiscountCode();

            bossting.setText(dress.getBoosting());

            int quantity = dress.getQuantity();
            Quality.setText(String.valueOf(quantity));
            Quality.setStyle(quantity < 10 ? "-fx-text-fill: red; -fx-font-weight: bold;" : "-fx-text-fill: black;");

            date.setText(dress.getDate());
            loadImage(dress.getImagePath());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadImage(String imagePath) {
        if (imagePath == null || imagePath.equals("N/A")) {
            imageload.setImage(null);
            return;
        }

        File imageFile = new File(imagePath);

        if (!imageFile.exists()) {
            imageFile = new File("src/main/resources/" + imagePath);
        }

        if (imageFile.exists()) {
            imageload.setImage(new Image(imageFile.toURI().toString()));
        } else {
            System.out.println("Image file not found: " + imagePath);
            imageload.setImage(null);
        }
    }

    /*private void loadTableData() {
        ObservableList<Dress> data = FXCollections.observableArrayList();

        try (Connection conn =connectionsigltion.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM dresses")) {

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                data.add(new Dress(
                        rs.getString("name"),
                        rs.getString("type"),
                        rs.getString("size"),
                        getColorName(rs.getString("color")),
                        rs.getDouble("price"),
                        rs.getString("details"),
                        rs.getString("gender"),
                        rs.getInt("quantity"),
                        rs.getString("purchase_date"),
                        rs.getString("discount_code"),
                        rs.getString("facebook_boost_status"),
                        rs.getString("image_path")
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        namecolumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        typecolumn.setCellValueFactory(new PropertyValueFactory<>("type"));
        pricecolumn.setCellValueFactory(new PropertyValueFactory<>("price"));
        quantitycolumn.setCellValueFactory(new PropertyValueFactory<>("quantity"));
        purchasecolumn.setCellValueFactory(new PropertyValueFactory<>("date"));
        boostedcolum.setCellValueFactory(new PropertyValueFactory<>("boosting"));
        colorcolumn.setCellValueFactory(new PropertyValueFactory<>("color"));

        tableview.setItems(data);
    }
    /*
     */
    private void loadTableData() {
        ObservableList<Dress> data = FXCollections.observableArrayList();

        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = ConnectionSingleton.getConnection(); // singleton connection
            stmt = conn.prepareStatement("SELECT * FROM dresses");
            rs = stmt.executeQuery();

            while (rs.next()) {
                data.add(new Dress(
                        rs.getString("name"),
                        rs.getString("type"),
                        rs.getString("size"),
                        getColorName(rs.getString("color")),
                        rs.getDouble("price"),
                        rs.getString("details"),
                        rs.getString("gender"),
                        rs.getInt("quantity"),
                        rs.getString("purchase_date"),
                        rs.getString("discount_code"),
                        rs.getString("facebook_boost_status"),
                        rs.getString("image_path")
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                // ❌ Do NOT close `conn`, since it's from Singleton
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }

        namecolumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        typecolumn.setCellValueFactory(new PropertyValueFactory<>("type"));
        pricecolumn.setCellValueFactory(new PropertyValueFactory<>("price"));
        quantitycolumn.setCellValueFactory(new PropertyValueFactory<>("quantity"));
        purchasecolumn.setCellValueFactory(new PropertyValueFactory<>("date"));
        boostedcolum.setCellValueFactory(new PropertyValueFactory<>("boosting"));
        colorcolumn.setCellValueFactory(new PropertyValueFactory<>("color"));

        tableview.setItems(data);
    }

    private String getColorName(String codeOrName) {
        if (codeOrName == null) return "N/A";
        switch (codeOrName.toLowerCase()) {
            case "0xff0000ff": case "#ff0000": return "Red";
            case "0x00ff00ff": case "#00ff00": return "Green";
            case "0x0000ffff": case "#0000ff": return "Blue";
            case "0xffff00ff": case "#ffff00": return "Yellow";
            case "0x000000ff": case "#000000": return "Black";
            case "0xffffffff": case "#ffffff": return "White";
            case "0x800080ff": case "#800080": return "Purple";
            case "0xffa500ff": case "#ffa500": return "Orange";
            case "0x008080ff": return "Teal";
            case "0xff00ffff": return "Magenta";
            default: return codeOrName;
        }
    }

    private void filterTable(String searchText) {
        ObservableList<Dress> filteredList = FXCollections.observableArrayList();

        try (Connection conn = ConnectionSingleton.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM dresses WHERE name LIKE ?")) {

            stmt.setString(1, "%" + searchText + "%");
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                filteredList.add(new Dress(
                        rs.getString("name"),
                        rs.getString("type"),
                        rs.getString("size"),
                        getColorName(rs.getString("color")),
                        rs.getDouble("price"),
                        rs.getString("details"),
                        rs.getString("gender"),
                        rs.getInt("quantity"),
                        rs.getString("purchase_date"),
                        rs.getString("discount_code"),
                        rs.getString("facebook_boost_status"),
                        rs.getString("image_path")
                ));
            }

            tableview.setItems(filteredList);

            if (!filteredList.isEmpty()) {
                updateUIWithDressData(filteredList.get(0));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}