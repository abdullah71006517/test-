package com.example.dresscollection;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.time.LocalDate;
import java.util.ResourceBundle;

public class HelloController implements Initializable {

    @FXML
    private TextField dressName;
    @FXML
    private Label dressNameError;

    @FXML
    private ChoiceBox<String> dressTypeChoiceBox;
    @FXML
    private Label dressTypeError;

    @FXML
    private ComboBox<String> sizeComboBox;

    @FXML
    private ColorPicker dressColor;
    @FXML
    private Label dressColorError;

    @FXML
    private Slider priceRange;
    @FXML
    private Label priceError;

    @FXML
    private TextArea dressDetails;
    @FXML
    private Label dressDetailsError;

    @FXML
    private DatePicker purchaseDate;
    @FXML
    private Label purchaseDateError;

    @FXML
    private Spinner<Integer> availableQuantity;
    @FXML
    private Label availableQuantityError;

    @FXML
    private PasswordField discountCode;

    @FXML
    private RadioButton maleRadio, femaleRadio;
    @FXML
    private ToggleGroup gender;

    @FXML
    private CheckBox facebookBoost;

    @FXML
    private ImageView dressImage;
    @FXML
    private File selectedImageFile;


    private void saveToDatabase(String name, String type, String size, String color, double price, String details,
                                String genderText, int quantity, String date, String discount, String facebookBoostStatus, String imagePath) {
       /* String url = "jdbc:mysql://localhost:3306/newapplication"; // Replace with your database name
        String user = "root";
        String password = "abdullah";*/

        String query = "INSERT INTO dresses (name, type, size, color, price, details, gender, quantity, purchase_date, discount_code, facebook_boost_status, image_path) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = ConnectionSingleton.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, name);
            stmt.setString(2, type);
            stmt.setString(3, size);
            stmt.setString(4, color);
            stmt.setDouble(5, price);
            stmt.setString(6, details);
            stmt.setString(7, genderText);
            stmt.setInt(8, quantity);
            stmt.setString(9, date != null ? date : null); // Handle null date
            stmt.setString(10, discount);
            stmt.setString(11, facebookBoostStatus);
            stmt.setString(12, imagePath);

            stmt.executeUpdate();
            System.out.println("Dress saved to database successfully.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        dressTypeChoiceBox.setItems(FXCollections.observableArrayList("Hoodie", "Sweater", "Jacket"));
        sizeComboBox.setItems(FXCollections.observableArrayList("Small", "Medium", "Large", "XL"));

        SpinnerValueFactory<Integer> quantityFactory = new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 1000, 1);
        availableQuantity.setValueFactory(quantityFactory);
    }

    @FXML
    private void handleUpload() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Select Dress Image");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg"));
        File file = fileChooser.showOpenDialog(new Stage());

        if (file != null) {
            try {
                File destDir = new File("src/main/resources/images");
                if (!destDir.exists()) destDir.mkdirs();

                File destFile = new File(destDir, file.getName());
                Files.copy(file.toPath(), destFile.toPath(), StandardCopyOption.REPLACE_EXISTING);

                selectedImageFile = new File("images/" + file.getName());

                dressImage.setImage(new Image(destFile.toURI().toString()));
                dressColorError.setVisible(false);
            } catch (IOException e) {
                e.printStackTrace();
                dressColorError.setText("Failed to upload image");
                dressColorError.setVisible(true);
            }
        } else {
            dressColorError.setText("Image is required");
            dressColorError.setVisible(true);
        }
    }

    @FXML
    private void nextpage() {
        HelloApplication.changeScene("2nd.fxml");
    }

    @FXML
    private void handleSave() {
        boolean valid = true;

        if (dressName.getText().isEmpty()) {
            dressNameError.setVisible(true);
            valid = false;
        } else {
            dressNameError.setVisible(false);
        }

        if (dressTypeChoiceBox.getValue() == null) {
            dressTypeError.setVisible(true);
            valid = false;
        } else {
            dressTypeError.setVisible(false);
        }

        if (dressColor.getValue() == null) {
            dressColorError.setVisible(true);
            valid = false;
        } else {
            dressColorError.setVisible(false);
        }

        if (priceRange.getValue() < 500) {
            priceError.setVisible(true);
            valid = false;
        } else {
            priceError.setVisible(false);
        }

        if (dressDetails.getText().length() > 50) {
            dressDetailsError.setVisible(true);
            valid = false;
        } else {
            dressDetailsError.setVisible(false);
        }

        if (purchaseDate.getValue() != null && purchaseDate.getValue().isAfter(LocalDate.now())) {
            purchaseDateError.setVisible(true);
            valid = false;
        } else {
            purchaseDateError.setVisible(false);
        }

        if (availableQuantity.getValue() < 0) {
            availableQuantityError.setVisible(true);
            valid = false;
        } else {
            availableQuantityError.setVisible(false);
        }

        if (valid) {
            String name = dressName.getText();
            String type = dressTypeChoiceBox.getValue();
            String size = sizeComboBox.getValue() != null ? sizeComboBox.getValue() : "N/A";
            String color = dressColor.getValue() != null ? dressColor.getValue().toString() : "N/A";
            double price = priceRange.getValue();
            String details = dressDetails.getText();
            String genderText = gender.getSelectedToggle() != null ? ((RadioButton) gender.getSelectedToggle()).getText() : "N/A";
            int quantity = availableQuantity.getValue();
            String date = purchaseDate.getValue() != null ? purchaseDate.getValue().toString() : null;
            String discount = discountCode.getText();
            String facebookBoostStatus = facebookBoost.isSelected() ? "Enabled" : "Not Enabled";
            String imagePath = selectedImageFile != null ? selectedImageFile.getPath() : "N/A";

            saveToDatabase(name, type, size, color, price, details, genderText, quantity, date, discount, facebookBoostStatus, imagePath);
        }
    }
}