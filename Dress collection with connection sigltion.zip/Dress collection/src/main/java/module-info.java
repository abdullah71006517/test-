module com.example.dresscollection {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens com.example.dresscollection to javafx.fxml;
    exports com.example.dresscollection;
}