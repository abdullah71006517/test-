package bd.edu.seu.demo;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class HelloController {
    @FXML
    private TextField logmobile;

    @FXML
    private TextField logpin;

    @FXML
    private TextField regmobile;

    @FXML
    private TextField regname;

    @FXML
    private TextField regpin;

    @FXML
    void loginevent(ActionEvent event) {

    }

    @FXML
    void regsisterevent(ActionEvent event) throws SQLException {

String regmob= regmobile.getText();
String regName = regname.getText();
String regPin = regpin.getText();
        System.out.println("regmob: " + regmob+", regName: " + regName+", regPin: " + regPin);

        try {
            Connection connection=DriverManager.getConnection("jdbc:mysql://localhost/seupay25","root" ,"seucse613");
            Statement statement=connection.createStatement();

            String query="INSERT INTO user VALUES('" +regName+"','"+regmob+"','"+regPin+"');";
            System.out.println(query);
            statement.executeUpdate(query);
            System.out.println("register success");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }


    }

}