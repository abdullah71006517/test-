module bd.edu.seu.demo {
    requires javafx.controls;
    requires javafx.fxml;
requires java.sql;

    opens bd.edu.seu.demo to javafx.fxml;
    exports bd.edu.seu.demo;
}